print(type(25.5))
print(type(25))
print(20+5)
print(20-5)
print(20*5)
print(20/5)
print(25**2)

number = input("Insert a Number:"); #Insertar datos
print(number);
new_number = int(number) + 5 ;
print(new_number);
print(type(int(number)));