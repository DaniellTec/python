name = "Meh";
print (name);

print (25 + 25);

d= "uwu";
print (d);

#Case sensitive

case = "Bored"
Case = "Bored"

a, case = 25, "Me aburro"
print(a);
print(case);

#Opciones
case_name = "case1"
caseName = "Case"
BookName = "Cases"

#Constantes
pi = 3.14
PI = 3.14