t = ((1, 3, 5, 7)); #Tiene que tener múltiples datos para ser una tupla
t1 = (1,) #Para que sea una tupla de un solo elemento
print(t);
print(type(t));
print(t1);

print(t[3]) #Para ver el valor de la posición