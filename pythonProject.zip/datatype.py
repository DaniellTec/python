#Strings
print("Hi");
print('Hi');
print('''Hi''');
print("""Hi""");

#Integer
i1=25;
print(type(i1));

#Float
f1=25.5;
print(f1);
print (type(f1))

#Boolean, dato lógico
True
False

#Lists
list1= [2, 11,' meh'];
print(list1);
list2=['Meh', 'Hi', 25];
print(list2);
print (type(list1))

#Tuples, se usa en datos que no cambían
tuple1=(25, 5);
print(tuple1);
print (type(tuple1))

#Dictonaries, mismo tipo de dato
#Nombre, valor
dict1={"Text:", "Bye"};
print(dict1)
print (type(dict1))
