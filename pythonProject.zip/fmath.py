def add (n1, n2):
    print(n1 + n2)

def susbstract (n1, n2):
    print(n1 - n2)    