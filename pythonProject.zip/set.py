#Colección que no tiene índice

colors = {"red", "blue","black"}

#print(type(colors));
print (colors);
print("black" in colors)

colors.add("cyan") #Añade 
print(colors)

colors.remove("red") #Elimina
print(colors)

#colors.clear() #Vcía el contenido
#print(colors)

#del colors
#print(colors) #Borra la variable