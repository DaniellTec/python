myStr= "hi, there"

#Opciones
print(dir(myStr))

print(myStr.upper()) #Mayúsculas
print(myStr.lower()) #Minúsculas
print(myStr.swapcase()) #Alterna
print(myStr.capitalize()) #Primera

print(myStr.replace("hi", "bye")) #Reemplaza
print(myStr. count('t')) #Cuenta la cantidad de letras

print(myStr.startswith('h'))
print(myStr.endswith('r'))

print(myStr.split()) #Separa el string
print(myStr.find('e')) #Muesra la posición
print(len(myStr)) ##Muestra la longitud
print(myStr.index('i'))

print(myStr.isnumeric())
print(myStr.isalpha())

print(myStr[0])
print(myStr[1]) #Muesta el carácter en esa posición

#print("print" = myStr)
#print("print {myStr}")
#print("Probando".format(myStr))